/**
 * class IteratorCantRemoveQueue for exception
 * @author Bilal Yalcinkaya
 */

public class IteratorCantRemoveQueue extends Exception{
	public IteratorCantRemoveQueue(String error){
		super(error);
	}
}