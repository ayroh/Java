/**
 * interface set
 * @author Bilal Yalcinkaya
 */

public interface set <E> extends collection<E>{
	
	public boolean isDuplicate(E e);
	
}