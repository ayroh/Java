/**
 * class WrongIndex for exception
 * @author Bilal Yalcinkaya
 */

public class WrongIndex extends Exception{
	public WrongIndex(String error){
		super(error);
	}
}