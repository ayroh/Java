import java.util.Random;

public class main{
	public static void main(String[] args) {
	

		System.out.printf("///////////////////////////////////////PART 1///////////////////////////////////////\n\n");
		System.out.printf("  MATRIXGRAPH -> For books example. This one is directed graph. I also added picture of graph to pdf.\n");
		MatrixGraph part1test = new MatrixGraph(5,true);
		part1test.insert(new Edge(0,1,10,0));
		part1test.insert(new Edge(1,2,50,0));
		part1test.insert(new Edge(0,3,30,0));
		part1test.insert(new Edge(3,2,20,0));
		part1test.insert(new Edge(3,4,60,0));
		part1test.insert(new Edge(0,4,100,0));
		part1test.insert(new Edge(2,4,10,0));
		int[] pred = new int[5];
		double[] dist = new double[5];
		DijkstrasAlgorithm.dijkstrasAlgorithm(part1test, 0, pred,dist,0,0);
		for(int i = 0;i < 5;i++)
			System.out.printf("dist[%d] -> %.1f  |  pred[%d] -> %d\n",i,dist[i],i,pred[i]);
		//System.out.printf("%f %f",DijkstrasAlgorithm.operation(DijkstrasAlgorithm.operation(1,2,1), 3,1), DijkstrasAlgorithm.operation(1,DijkstrasAlgorithm.operation(2,3,1),1));

		System.out.printf("\n\n\n  LISTGRAPH -> This Time for Distance property which symbolizes with '1' and instead\n               of addition operation i used * binary operation. Also this graph is not directed.\n");
		ListGraph part1test2 = new ListGraph(6,false);
		part1test2.insert(new Edge(0,1,7,1));
		part1test2.insert(new Edge(0,5,14,1));
		part1test2.insert(new Edge(0,2,9,1));
		part1test2.insert(new Edge(1,2,10,1));
		part1test2.insert(new Edge(1,3,15,1));
		part1test2.insert(new Edge(3,4,60,1));
		part1test2.insert(new Edge(4,5,9,1));
		part1test2.insert(new Edge(5,2,2,1));
		part1test2.insert(new Edge(2,3,11,1));
		pred = new int[6];
		dist = new double[6];
		DijkstrasAlgorithm.dijkstrasAlgorithm(part1test2, 0, pred,dist,1,1);
		for(int i = 0;i < 6;i++)
			System.out.printf("dist[%d] -> %.1f  |  pred[%d] -> %d\n",i,dist[i],i,pred[i]);
		System.out.printf("\n\n\n");


		System.out.printf("///////////////////////////////////////PART 2///////////////////////////////////////");
		ListGraph part2test = new ListGraph(6,false);
		part2test.insert(new Edge(0,1));
		part2test.insert(new Edge(2,1));
		part2test.insert(new Edge(3,4));
		System.out.printf("\n\n   Creating ListGraph(6): Edge(0,1), Edge(2,1), Edge(3,4)\n");
		System.out.printf("   Result should be 3: 0-1-2 3-4 5\n\n");
		System.out.printf("BreadthFirstSearch.numberOfConnectedNodesBFS(): %d\n",BreadthFirstSearch.numberOfConnectedNodesBFS(part2test));
		DepthFirstSearch dsf2test = new DepthFirstSearch(part2test);
		System.out.printf("DepthFirstSearch().getConnectedNodes(): %d",dsf2test.getConnectedNodes());

		MatrixGraph part2test2 = new MatrixGraph(7,false);
		part2test2.insert(new Edge(0,2));
		part2test2.insert(new Edge(2,1));
		part2test2.insert(new Edge(4,5));
		System.out.printf("\n\n   Creating MatrixGraph(7): Edge(0,2), Edge(2,1), Edge(4,5)\n");
		System.out.printf("   Result should be 4: 0-2-1 3 4-5 6\n\n");
		System.out.printf("BreadthFirstSearch.numberOfConnectedNodesBFS(): %d\n",BreadthFirstSearch.numberOfConnectedNodesBFS(part2test2));
		DepthFirstSearch dsf2test2 = new DepthFirstSearch(part2test2);
		System.out.printf("DepthFirstSearch().getConnectedNodes(): %d",dsf2test2.getConnectedNodes());

		
		double start = 0, end = 0,dfstimetemp = 0, bfstimetemp = 0;
		for(int j = 0;j < 10;j++){
			ListGraph lg = new ListGraph(1000,false);
			Random rand = new Random();
			for(int i = 0;i < 1000;i++){
				int y = rand.nextInt(1000);
				int x = rand.nextInt(1000);
				if(x == y){
					i--;
					continue;
				}
				lg.insert(new Edge(x, y));
			}
			if(j == 0)
				continue;
			start = System.nanoTime();
			DepthFirstSearch dsf = new DepthFirstSearch(lg);
			dsf.getConnectedNodes();
			end = System.nanoTime();
			dfstimetemp += end - start;

			start = System.nanoTime();
			BreadthFirstSearch.numberOfConnectedNodesBFS(lg);
			end = System.nanoTime();
			bfstimetemp += end - start;

		}
			bfstimetemp /= 1000000000;
			dfstimetemp /= 1000000000;
			bfstimetemp /= 10;
			dfstimetemp /= 10;
			System.out.printf("\n\n\n\nbfs : %f  |  dfs: %f    <--- 1000 Elements\n",bfstimetemp,dfstimetemp);


		start = 0; end = 0;dfstimetemp = 0; bfstimetemp = 0;
		for(int j = 0;j < 10;j++){
			ListGraph lg = new ListGraph(2000,false);
			Random rand = new Random();
			for(int i = 0;i < 2000;i++){
				int y = rand.nextInt(2000);
				int x = rand.nextInt(2000);
				if(x == y){
					i--;
					continue;
				}
				lg.insert(new Edge(x, y));
			}
			if(j == 0)
				continue;
			start = System.nanoTime();
			DepthFirstSearch dsf = new DepthFirstSearch(lg);
			dsf.getConnectedNodes();
			end = System.nanoTime();
			dfstimetemp += end - start;

			start = System.nanoTime();
			BreadthFirstSearch.numberOfConnectedNodesBFS(lg);
			end = System.nanoTime();
			bfstimetemp += end - start;

		}
			bfstimetemp /= 1000000000;
			dfstimetemp /= 1000000000;
			bfstimetemp /= 10;
			dfstimetemp /= 10;
			System.out.printf("bfs : %f  |  dfs: %f    <--- 2000 Elements\n",bfstimetemp,dfstimetemp);



		start = 0; end = 0;dfstimetemp = 0; bfstimetemp = 0;
		for(int j = 0;j < 10;j++){
			ListGraph lg = new ListGraph(5000,false);
			Random rand = new Random();
			for(int i = 0;i < 5000;i++){
				int y = rand.nextInt(5000);
				int x = rand.nextInt(5000);
				if(x == y){
					i--;
					continue;
				}
				lg.insert(new Edge(x, y));
			}
			if(j == 0)
				continue;
			start = System.nanoTime();
			DepthFirstSearch dsf = new DepthFirstSearch(lg);
			dsf.getConnectedNodes();
			end = System.nanoTime();
			dfstimetemp += end - start;

			start = System.nanoTime();
			BreadthFirstSearch.numberOfConnectedNodesBFS(lg);
			end = System.nanoTime();
			bfstimetemp += end - start;

		}
			bfstimetemp /= 1000000000;
			dfstimetemp /= 1000000000;
			bfstimetemp /= 10;
			dfstimetemp /= 10;
			System.out.printf("bfs : %f  |  dfs: %f    <--- 5000 Elements\n",bfstimetemp,dfstimetemp);




		start = 0; end = 0;dfstimetemp = 0; bfstimetemp = 0;
		for(int j = 0;j < 10;j++){
			ListGraph lg = new ListGraph(10000,false);
			Random rand = new Random();
			for(int i = 0;i < 10000;i++){
				int y = rand.nextInt(10000);
				int x = rand.nextInt(10000);
				if(x == y){
					i--;
					continue;
				}
				lg.insert(new Edge(x, y));
			}
			if(j == 0)
				continue;
			start = System.nanoTime();
			DepthFirstSearch dsf = new DepthFirstSearch(lg);
			dsf.getConnectedNodes();
			end = System.nanoTime();
			dfstimetemp += end - start;

			start = System.nanoTime();
			BreadthFirstSearch.numberOfConnectedNodesBFS(lg);
			end = System.nanoTime();
			bfstimetemp += end - start;

		}
			bfstimetemp /= 1000000000;
			dfstimetemp /= 1000000000;
			bfstimetemp /= 10;
			dfstimetemp /= 10;
			System.out.printf("bfs : %f  |  dfs: %f    <--- 10000 Elements\n",bfstimetemp,dfstimetemp);




	}
}