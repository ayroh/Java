import java.util.Iterator;

public class MatrixGraph
    extends AbstractGraph {

  private double[][][] edges;

  public MatrixGraph(int numV, boolean directed) {
    super(numV, directed);
    edges = new double[numV][][];
    for (int i = 0; i != numV; ++i) {
      edges[i] = new double[numV][];
      for (int j = 0; j != numV; ++j) {
        edges[i][j] = new double[4];
        for (int k = 0;k < 4;k++) {
          edges[i][j][k] = Double.POSITIVE_INFINITY;
        }
      }
    }
  }

  /** Insert a new edge into the graph
   */
  public void insert(Edge edge) {
    setEdgeValue(edge.getSource(), edge.getDest(),edge.getWeight(),0);
    setEdgeValue(edge.getSource(), edge.getDest(),edge.getDistance(),1);
    setEdgeValue(edge.getSource(), edge.getDest(),edge.getTime(),2);
    setEdgeValue(edge.getSource(), edge.getDest(),edge.getQuality(),3);
  }

  /** Determine if an edge exists
   */
  public boolean isEdge(int source, int dest) {
    return Double.POSITIVE_INFINITY != getEdgeValue(source, dest);
  }

  /** Get the edge between two vertices. If
      edge does not exist, Edge with a weight
      of POSITIVE_INFINITY is returned.
   */
  public Edge getEdge(int source, int dest) {
    return new Edge(source, dest,
                    getEdgeValue(source, dest, 0), getEdgeValue(source, dest, 1), getEdgeValue(source, dest, 2), getEdgeValue(source, dest, 3));
  }

  public Edge getEdge(int source, int dest, int selection) {
    return new Edge(source, dest,
                    getEdgeValue(source, dest, selection));
  }

  /** Return an iterator to the edges connected
      to a given vertix.
   */
  public Iterator < Edge > edgeIterator(int source) {
    return new Iter(source);
  }

  /** Method to set the weigth of an edge
   */
  private void setEdgeValue(int source, int dest, double wt) {
      edges[source][dest][0] = wt;
      if(!isDirected())
        edges[dest][source][0] = wt;
  }

  /** Method to set the property of an edge
   */
  private void setEdgeValue(int source, int dest, double temp, int selection) {
      edges[source][dest][selection] = temp;
      if(!isDirected())
        edges[dest][source][selection] = temp;
  }

  /** Method to get the weight of an edge
   */
  private double getEdgeValue(int source, int dest) {
    if (isDirected() | source <= dest) {
      return edges[source][dest][0];
    }
    else {
      return edges[dest][source][0];
    }
  }

  /** Method to get property of an edge
   */
  private double getEdgeValue(int source, int dest, int selection) {
    if (isDirected() | source <= dest) {
      return edges[source][dest][selection];
    }
    else {
      return edges[dest][source][selection];
    }
  }

  private class Iter
      implements Iterator < Edge > {

    private int source;

    private int index;

    public Iter(int source) {
      this.source = source;
      index = -1;
      advanceIndex();
    }

    public boolean hasNext() {
      return index != getNumV();
    }

    public Edge next() {
      if (index == getNumV()) {
        throw new java.util.NoSuchElementException();
      }
      Edge returnValue = new Edge(source, index, getEdgeValue(source, index));
      advanceIndex();
      return returnValue;
    }

    /** Advance the index to the next edge */
    private void advanceIndex() {
      do {
        index++;
      }
      while (index != getNumV() && Double.POSITIVE_INFINITY == getEdgeValue(source, index));
    }

  
  }

  /**** END EXERCISE ****/
}
